<?php require_once( '../couch/cms.php' ); ?>
<cms:template title="Delete All Cloned Pages" parent="_superadmin_" order="1000" />
<cms:embed "header.html" />
<div class="site-container">
	<div class="container">
		<div class="row">
			<div class="col-12 col-md-12 mb-5">
				<h5 class="headline-5 mb-3">
					Useful Links
				</h5>
				<ul>
					<li>
						<a href="<cms:show k_admin_link />" target="_blank">
							Backend <i class="fa fa-external-link"></i>
						</a>
					</li>
				</ul>
			</div>
		</div>

		<hr>

		<div class="row">
			<div class="col-12 col-md-12 my-5">
				<h5 class="headline-5 mb-3">
					Template Links
				</h5>
				<ul>
					<cms:templates order="desc" orderby="template_title">
						<cms:if k_template_name eq 'superadmin/index.php'>
				        <cms:else />
							<li>
				            	<a href="<cms:show k_site_link /><cms:show k_template_name />" target="_blank">
				                	<cms:if k_template_title>
				                		<cms:show k_template_title />
				                	<cms:else />
				                		<cms:show k_template_name />
				                	</cms:if>
				            	</a>
			        		</li>
			        	</cms:if>
			        </cms:templates>
		        </ul>
			</div>
		</div>
	</div>
</div>
<cms:embed "footer.html" />
<?php COUCH::invoke(); ?>