<?php
if ( !defined('K_COUCH_DIR') ) die(); // cannot be loaded directly

//require_once( K_COUCH_DIR.'addons/cart/cart.php' );
//require_once( K_COUCH_DIR.'addons/inline/inline.php' );
//require_once( K_COUCH_DIR.'addons/extended/extended-folders.php' );
//require_once( K_COUCH_DIR.'addons/extended/extended-comments.php' );
require_once( K_COUCH_DIR.'addons/extended/extended-users.php' );
//require_once( K_COUCH_DIR.'addons/routes/routes.php' );
//require_once( K_COUCH_DIR.'addons/jcropthumb/jcropthumb.php' );
//require_once( K_COUCH_DIR.'addons/page-builder/page-builder.php' );
require_once( K_COUCH_DIR.'addons/cart/session.php' );
require_once( K_COUCH_DIR.'addons/data-bound-form/data-bound-form.php' );

// Custom Routes
require_once( K_COUCH_DIR.'addons/routes/routes.php' );
// Custom Routes

// Sidebar Grouping
if( defined('K_ADMIN') ){
    $FUNCS->add_event_listener( 'register_admin_menuitems', 'my_register_admin_menuitems' );

    function my_register_admin_menuitems(){
        global $FUNCS;
        
        $FUNCS->register_admin_menuitem( array('name'=>'_jobs_', 'title'=>'Jobs', 'is_header'=>'1', 'weight'=>'1')  );
        $FUNCS->register_admin_menuitem( array('name'=>'_dispute_', 'title'=>'Dispute', 'is_header'=>'1', 'weight'=>'2')  );
        $FUNCS->register_admin_menuitem( array('name'=>'_users_', 'title'=>'Extended Users (Module)', 'is_header'=>'1', 'weight'=>'100')  );
        $FUNCS->register_admin_menuitem( array('name'=>'_superadmin_', 'title'=>'Superadmin', 'is_header'=>'1', 'weight'=>'1000')  );
        
    }
}
// Sidebar Grouping

// Sequential Id Addon
require_once( K_COUCH_DIR.'addons/uid/uid.php' );
// Sequential Id Addon