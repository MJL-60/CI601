<?php

    if ( !defined('K_COUCH_DIR') ) die(); // cannot be loaded directly

    ///////////EDIT BELOW THIS////////////////////////////////////////

    // Names of the required templates
     $t['users_tpl'] = 'users/index.php';
     $t['login_tpl'] = 'users/login.php';
     $t['lost_password_tpl'] = 'users/lost-password.php';
     $t['registration_tpl'] = 'users/register.php';
