<?php require_once( 'couch/cms.php' ); ?>
<cms:template title="Profile Comments" clonable="1" order="2" parent="_users_">
    <cms:editable name="user_commenting" label="Comment by User" type="relation" masterpage="users/index.php" has="one" order="1" />
    <cms:editable name="user_commented" label="Comment on User" type="relation" masterpage="users/index.php" has="one" order="2" />
    <cms:editable name="comment" label="Comment" type="textarea" no_xss_check="1" order="3" />
</cms:template>
<?php COUCH::invoke(); ?>