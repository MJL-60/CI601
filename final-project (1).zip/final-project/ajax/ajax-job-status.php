<?php require_once( '../couch/cms.php' ); ?>
<cms:template title='AJAX - Job Status Update' parent="_jobs_" order="100" />
<cms:set save_id = "<cms:gpc 'id' method='POST' />" scope="global" />
<cms:set save_job_accepted_by = "<cms:gpc 'job_accepted_by' method='POST' />" scope="global" />
<cms:set save_job_status = "<cms:gpc 'job_status' method='POST' />" scope="global" />

<cms:if save_job_status eq "Posted">
	<cms:db_persist
		_masterpage='jobs/jobtemp.php'
		_mode='edit'
		_page_id=save_id
		_invalidate_cache='1'

		job_status = "Accepted"
		accepted_status = "Accepted"
		accepted_by_user = "<cms:show save_job_accepted_by />"
		accepted_date = "<cms:date format='Y-m-d H:i' />"
	>
		<cms:if k_error>
			<cms:show k_error />
		<cms:else />
			<cms:show "1" />
		</cms:if>
	</cms:db_persist>

<cms:else_if save_job_status eq "Accepted" />
	<cms:db_persist
		_masterpage='jobs/jobtemp.php'
		_mode='edit'
		_page_id=save_id
		_invalidate_cache='1'

		job_status = "Posted"
		accepted_status = ""
		accepted_by_user = ""
		accepted_date = ""
	>
		<cms:if k_error>
			<cms:show k_error />
		<cms:else />
			<cms:show "1" />
		</cms:if>
	</cms:db_persist>

<cms:else_if save_job_status eq "" />
	<cms:db_persist
		_masterpage='jobs/jobtemp.php'
		_mode='edit'
		_page_id=save_id
		_invalidate_cache='1'

		job_status = "Completed"
		completed_date = "<cms:date format='Y-m-d H:i' />"
	>
		<cms:if k_error>
			<cms:show k_error />
		<cms:else />
			<cms:show "1" />
		</cms:if>
	</cms:db_persist>
</cms:if>
<?php COUCH::invoke( ); ?>