<?php require_once( 'couch/cms.php' ); ?>
<cms:template title="Home Page" order="2">
    
</cms:template>
<cms:embed "header.html" />
<div class="site-container">
    <div class="container">
        <div class="row">
            <div class="col-12 col-md-3 mb-3">
                <cms:pages masterpage=k_user_template id=k_user_id limit="1" show_future_enteries="1">
                    <div class="card shadow">
                        <div class="profile-img-container">
                            <img class="profile-image shadow"/>
                        </div>
                        <div class="card-body">
                            <table style="margin:0px;">
                                <tr>
                                    <td class="button text-primary">
                                        <a href="<cms:link 'users/profile.php' />" class="text-link">
                                            <i class="fa fa-edit"></i> Edit Profile
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="headline-5">
                                        <cms:show firstname /> <cms:show lastname /> 
                                    </td>
                                </tr>
                                <tr>
                                    <td class="body-2">
                                        <cms:show extended_user_email />
                                    </td>
                                </tr>
                                <tr>
                                    <td class="body-2">
                                        <cms:show mobile />
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <div class="card-body">
                            <div class="headline-6">
                                <cms:show phrase />
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="card-text">
                                <cms:php>
                                    global $age;
                                    $birthDate = "<cms:date dob format='m/d/Y' />";
                                    $birthDate = explode("/", $birthDate);
                                    $age = (date("md", date("U", mktime(0, 0, 0, $birthDate[0], $birthDate[1], $birthDate[2]))) > date("md") ? ((date("Y") - $birthDate[2]) - 1)
                                    : (date("Y") - $birthDate[2]));
                                </cms:php>
                                <strong>Age (in years)</strong> : <cms:php>global $age; echo $age;</cms:php> Yrs
                                <br>
                                <strong>Sex:</strong><cms:if sex><cms:show sex /></cms:if>
                                <br>
                                <strong>Located at:</strong><cms:show city /><cms:if country>,</cms:if> <cms:show country />
                            </div>
                        </div>
                    </div>
                </cms:pages>
            </div>
            <div class="col-12 col-md-6 mb-3">
                <div class="headline-1 text-center mb-3">
                    My Puzzle
                </div>
                <cms:pages masterpage=k_user_template id=k_user_id limit="1" show_future_enteries="1">
                    <div class="card shadow mb-3">
                        <div class="card-body">
                            <div class="headline-5 mb-3">
                                About Me
                            </div>
                            <div class="body-1">
                                <cms:show about />
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12 col-md-12 mb-3">
                            <div class="card shadow">
                                <div class="card-body">
                                    <div class="headline-5 mb-3">
                                        Expertise
                                    </div>
                                    <div class="body-1">
                                        <cms:show expertise />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-12 mb-3">
                            <div class="card shadow">
                                <div class="card-body">
                                    <div class="headline-5 mb-3">
                                        Goals
                                    </div>
                                    <div class="body-1">
                                        <cms:show goals />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </cms:pages>
            </div>
            <div class="col-12 col-md-3 mb-3">
<!--                Add comment box here -->
<!--                Comment Box-->
                <cms:if k_logged_in>
                    <cms:if global_userid ne k_user_id>
                        <div class="card shadow mb-3">
                            <div class="card-body">
                        <h5 class="headline-5">
                            Give me a feedback!
                        </h5>
                        <h6 class="card-subtitle mb-3 text-muted">
                            <cms:set submit_success="<cms:get_flash 'submit_success' />" />
                            <cms:if submit_success >
                                <h4>Success: Your application has been submitted.</h4>
                            </cms:if>

                            <cms:form
                                masterpage="comments.php"
                                mode='create'
                                enctype='multipart/form-data'
                                method='post'
                                anchor='0'
                                >

                                <cms:if k_success >

                                    <cms:check_spam email=frm_email />

                                    <cms:db_persist_form
                                        _invalidate_cache='0'
                                        _auto_title='0'
                                        k_page_title = ""
                                        k_page_name = "<cms:random_name />"
                                        user_commenting = k_user_id
                                        user_commented = "<cms:gpc />"
                                    />

                                    <cms:set_flash name='submit_success' value='1' />
                                    <cms:redirect k_page_link />
                                </cms:if>

                                <cms:if k_error >
                                    <div class="error">
                                        <cms:each k_error >
                                            <br><cms:show item />
                                        </cms:each>
                                    </div>
                                </cms:if>
                                <div class="form-floating mb-3">
                                    <cms:input name="comment" id="comment" type="bound" class="form-control" placeholder="Leave a feedback comment here" id="comment" />
                                    <label for="comment">Feedback</label>
                                </div>
                                <button class="btn btn-warning button" type="submit" style="margin-bottom:0;">
                                    <i class="fa fa-comment"></i> Post Feedback
                                </button>
                            </cms:form>
                        </h6>
                    </div>
                        </div>
                    </cms:if>
                </cms:if>
                
                <div class="card shadow mb-3">
                    <div class="card-body">
                        <h5 class="headline-5">
                            Feedback
                        </h5>
                        <h6 class="card-subtitle mb-3 text-muted">
                            What people feel about me?
                        </h6>
                    </div>
                </div>

                
                <cms:pages masterpage="comments.php" show_future_entries='1'>
                    <cms:if user_commented eq k_user_id >
                    <cms:no_results>
                        <div class="col-md-12">
                            <div class="alert alert-warning shadow text-center">
                                - No feedback yet. Be the first one to leave a comment. -
                            </div>
                        </div>
                    </cms:no_results>

                    <div class="card shadow mb-3">
                        <div class="card-body">
                            <div class="card-text mb-3">
                                <cms:show comment />
                            </div>
                            <h6 class="card-subtitle text-muted text-end">
                                - <cms:related_pages 'user_commenting'><cms:show firstname /> <cms:Show lastname /></cms:related_pages>
                            </h6>
                        </div>
                    </div>
                    </cms:if>
                </cms:pages>
            
            </div>
        </div>
    </div>
</div>
<cms:embed "footer.html" />
<?php COUCH::invoke(); ?>